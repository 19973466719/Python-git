
import mod

print(mod.v)
print(mod.f())
print(mod.MyClass)

print(mod._v)
print(mod._f())
print(mod._MyClass)