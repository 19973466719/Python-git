
class MyClass(object):
    def __init__(self):
        self.__pia = 18

    def __pim(self):
        print("__pim()被调用了")

    def do_sth(self):
        print(self.__pia)
        self.__pim()

mc = MyClass()

# print(mc.__pia) 
# mc.__pim()

mc.do_sth()


print(mc._MyClass__pia) 
mc._MyClass__pim()     
print(dir(mc))


mc.__pia = "Hi"
print(mc.__pia)     
print(dir(mc))


class SomeClass(object):
    def __init__(self):
        self._pia = 18

    def _pim(self):
        print("_pim()被调用了")

sc = SomeClass()

print(sc._pia)  
sc._pim()     
