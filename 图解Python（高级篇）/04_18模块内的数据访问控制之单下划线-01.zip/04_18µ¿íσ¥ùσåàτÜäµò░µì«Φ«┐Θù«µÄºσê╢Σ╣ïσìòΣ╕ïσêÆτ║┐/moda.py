
from mod import *

print(v)
print(f())
print(MyClass)

# print(_v)
# print(_f())
# print(_MyClass)