
class ParentClassA(object):
    ca = 18

    def im(self):
        print("im()被调用了")

class ParentClassB(object):
    __pca = 23

    def __pim(self):
        print("__pim()被调用了")

class ParentClassC(ParentClassA, ParentClassB):
    @classmethod
    def cm(cls):
        print("cm()被调用了")

class ParentClassD(object):
    @staticmethod
    def sm():
        print("sm()被调用了")

class ChildClass(ParentClassC, ParentClassD):
    pass

print(dir(ChildClass))



class BaseClass(object):
    ca_base = 5

    def im_base(self):
        print("im_base()被调用了")

class SubClass(BaseClass):
    ca_sub = 8

    def im_sub(self):
        print("im_sub()被调用了")

print(dir(SubClass))

