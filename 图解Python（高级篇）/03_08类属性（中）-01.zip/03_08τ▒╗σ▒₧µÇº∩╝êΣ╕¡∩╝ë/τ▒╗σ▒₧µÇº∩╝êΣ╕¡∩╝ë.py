
class MyClass(object):
    ca1 = 18

    def do_sth(self):
        print(MyClass.ca1)

    def do_another(self):
        print(MyClass.ca2)

mc = MyClass()

mc.do_sth()

print(MyClass.ca1)
print(mc.ca1)      

MyClass.ca2 = 56
print(MyClass.ca2)  
print(mc.ca2)       
MyClass.ca2 = 73
print(MyClass.ca2)  
print(mc.ca2)       

mc.do_another()
