
v = 18
_v = 56

def f():
    pass

def _f():
    pass

class MyClass(object):
    pass

class _MyClass(object):
    pass