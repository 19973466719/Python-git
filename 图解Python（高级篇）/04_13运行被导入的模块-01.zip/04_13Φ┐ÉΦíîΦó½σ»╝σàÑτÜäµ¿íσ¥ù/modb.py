
import moda

print('模块modb被运行')