
__all__ = ['v1', 'f1', 'C1']

v1 = 18
v2 = 36

def f1():
    pass

def f2():
    pass

class C1(object):
    pass

class C2(object):
    pass