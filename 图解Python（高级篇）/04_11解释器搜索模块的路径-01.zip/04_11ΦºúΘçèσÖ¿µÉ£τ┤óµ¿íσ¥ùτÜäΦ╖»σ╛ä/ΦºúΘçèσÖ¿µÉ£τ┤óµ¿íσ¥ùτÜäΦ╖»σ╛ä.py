
# import my_module
# my_module.f()

import sys
sys.path.insert(0, '/Users/zhangrongchao/Downloads')

import my_module
my_module.f()   # f被调用（Downloads目录）
