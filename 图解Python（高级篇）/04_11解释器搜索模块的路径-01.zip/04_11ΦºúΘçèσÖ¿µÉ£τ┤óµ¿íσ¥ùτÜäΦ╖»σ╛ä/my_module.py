
def f():
    print('f被调用（Downloads目录）')