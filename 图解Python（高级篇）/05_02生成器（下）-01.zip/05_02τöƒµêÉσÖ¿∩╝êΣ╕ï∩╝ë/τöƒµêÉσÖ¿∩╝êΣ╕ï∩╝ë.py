
def fib(n):
    i = 0
    a, b = 1, 1
    while i < n:
        yield a
        a, b = b, a + b
        i += 1

gf = fib(6)
print(gf)  

print(next(gf))     
print(next(gf))    
print(next(gf))    
print(next(gf))     
print(next(gf))     
print(next(gf))     
# print(next(gf))   

gf = fib(6)

for item in gf:
    print(item)