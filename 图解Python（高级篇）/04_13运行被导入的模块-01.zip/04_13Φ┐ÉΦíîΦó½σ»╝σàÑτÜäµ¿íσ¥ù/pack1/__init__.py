
print('pack1.__init__.py')