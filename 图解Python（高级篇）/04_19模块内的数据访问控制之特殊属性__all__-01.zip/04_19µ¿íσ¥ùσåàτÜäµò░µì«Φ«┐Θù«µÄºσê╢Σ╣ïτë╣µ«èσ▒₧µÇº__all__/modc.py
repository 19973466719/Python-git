
__all__ = ['_v', '_f', '_C']

_v = 18

def _f():
    pass

class _C(object):
    pass