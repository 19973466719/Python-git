
class Dog(object):
    def __init__(self, breed, name, age, health):
        self.breed = breed      # 品种
        self.name = name        # 昵称
        self.age = age          # 年龄
        self.health = health    # 健康状况

    # 跑
    def run(self):
        print("Dog is running")

    # 吠
    def bark(self):
        print("Dog is barking")

    # 咬
    def bite(self):
        print("Dog is biting")

dog = Dog("拉布拉多", "旺财", 3, "很好")

print(dog.breed)
print(dog.name)
print(dog.age)
print(dog.health)

dog.run()
dog.bark()
dog.bite()










