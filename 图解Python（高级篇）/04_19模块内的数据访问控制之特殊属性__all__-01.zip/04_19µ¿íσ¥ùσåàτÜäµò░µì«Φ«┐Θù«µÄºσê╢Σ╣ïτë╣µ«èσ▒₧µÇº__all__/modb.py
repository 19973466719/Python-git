
import mod

print(mod.v1)
print(mod.f1())
print(mod.C1)

print(mod.v2)
print(mod.f2())
print(mod.C2)