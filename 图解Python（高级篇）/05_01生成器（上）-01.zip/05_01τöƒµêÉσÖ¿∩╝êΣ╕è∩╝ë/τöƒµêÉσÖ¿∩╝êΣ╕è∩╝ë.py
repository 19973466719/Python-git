
ge = (i * i for i in range(1, 7))
print(ge)

print(next(ge))    
print(next(ge))    
print(next(ge))   
print(next(ge))   
print(next(ge))   
print(next(ge))   
# print(next(ge))   

ge = (i * i for i in range(1, 7))

for item in ge:
    print(item)
