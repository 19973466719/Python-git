
import pack1.pack2.pack3.modc

print('模块modd被运行')
