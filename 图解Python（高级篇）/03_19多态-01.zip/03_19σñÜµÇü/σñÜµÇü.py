
class ParentClass(object):
    def do_sth(self):
        print("do_sth() in ParentClass")

class ChildClass1(ParentClass):
    def do_sth(self):
        print("do_sth() in ChildClass1")

class ChildClass2(ParentClass):
    def do_sth(self):
        print("do_sth() in ChildClass2")

class ChildClass3(ParentClass):
    pass

class SomeClass(object):
    def do_sth(self):
        print("do_sth() in SomeClass")

def f(parent):
    parent.do_sth()

f(ParentClass())    
f(ChildClass1())  
f(ChildClass2())    
f(SomeClass())    

f(ChildClass3())    

