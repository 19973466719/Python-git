
print('pack2.__init__.py')