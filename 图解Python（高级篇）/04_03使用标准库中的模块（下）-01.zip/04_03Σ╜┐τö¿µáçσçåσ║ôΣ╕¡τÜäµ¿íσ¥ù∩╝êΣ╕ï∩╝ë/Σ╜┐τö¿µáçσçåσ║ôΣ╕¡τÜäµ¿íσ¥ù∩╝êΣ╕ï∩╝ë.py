
# from os import environ
# print(environ)

# from os import getenv
# print(getenv('PYTHON_HOME'))

# from os import MutableMapping
# print(MutableMapping)

# from xml.dom.minidom import StringTypes
# print(StringTypes)


# from os import environ, getenv, MutableMapping
# print(environ)
# print(getenv('PYTHON_HOME'))
# print(MutableMapping)


# from os import environ as er, getenv as ge, MutableMapping as MM
# print(er)
# print(ge('PYTHON_HOME'))
# print(MM)


from os import *
print(environ)
print(getenv('PYTHON_HOME'))
# print(MutableMapping)


from xml.dom import minidom
print(minidom.StringTypes)











