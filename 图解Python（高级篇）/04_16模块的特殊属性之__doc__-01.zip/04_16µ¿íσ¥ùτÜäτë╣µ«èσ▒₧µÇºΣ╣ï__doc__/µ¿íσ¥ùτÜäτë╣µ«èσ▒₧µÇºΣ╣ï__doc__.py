
print(__doc__)

import base64
print(base64.__doc__)

print(help(base64))



