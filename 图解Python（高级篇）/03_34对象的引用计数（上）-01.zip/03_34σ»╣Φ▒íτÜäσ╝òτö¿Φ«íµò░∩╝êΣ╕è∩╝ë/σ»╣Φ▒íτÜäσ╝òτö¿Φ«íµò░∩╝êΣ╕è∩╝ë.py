
class MyClass(object):
    pass

def do_sth(param):
    pass

a = MyClass()

b = a

L = [1, 2, a]

do_sth(a)

import sys
print(sys.getrefcount(a))   
