
from modc import *

print(_v)
print(_f())
print(_C)