
try:
    result = 1 / 0
    print(result)
except ArithmeticError:
    print("数学错误")


try:
    result = 1 / 0
    print(result)
except ZeroDivisionError:
    print("0不能作为除数")
except ArithmeticError:
    print("数学错误")
print("结束")

try:
    result = 1 / 0
    print(result)
except ArithmeticError:
    print("数学错误")
except ZeroDivisionError:
    print("0不能作为除数")
print("结束")


try:
    result = 1 / 0
    print(result)
except TypeError:
    print("运行出错了")
except ZeroDivisionError:
    print("运行出错了")
except ValueError:
    print("运行出错了")

try:
    result = 1 / 0
    print(result)
except (TypeError, ZeroDivisionError, ValueError):
    print("运行出错了")


try:
    result = 1 / 0
    print(result)
except ZeroDivisionError as err:
    print(type(err))    
    print(err)    

try:
    result = int('abc')
    print(result)
except (TypeError, ZeroDivisionError, ValueError) as err:
    print(type(err))    
    print(err)  


try:
    result = 1 / 0
    print(result)
except (TypeError, ValueError):
    print("类型错误或值错误")
# except:
except Exception:
    print("其它错误")