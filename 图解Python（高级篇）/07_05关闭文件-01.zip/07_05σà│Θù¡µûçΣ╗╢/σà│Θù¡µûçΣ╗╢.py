
file = open('myfile.txt', 'w')
try:
    file.write('hello')
finally:
    file.close()

with open('myfile.txt', 'a') as file:
    file.write('python')