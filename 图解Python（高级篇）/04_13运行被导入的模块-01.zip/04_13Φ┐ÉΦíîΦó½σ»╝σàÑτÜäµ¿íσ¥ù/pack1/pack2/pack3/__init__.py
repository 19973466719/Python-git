
print('pack3.__init__.py')