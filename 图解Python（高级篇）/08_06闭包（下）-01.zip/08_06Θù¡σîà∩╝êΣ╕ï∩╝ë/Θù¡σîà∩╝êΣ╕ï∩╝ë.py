
def outer2():
    a = 10
    def inner2():
        # a = 11

        # a += 1

        pass
    return inner2

def outer3():
    a = [3]
    def inner3():
        # a = [1]

        a[0] = 8

        print(a)
    return inner3

outer3()() 


def outer4():
    a = 10
    def inner4():
        nonlocal a

        # a = 11
        a += 1

        print(a)
    return inner4

outer4_result = outer4()
outer4_result()     


outer4_result()     