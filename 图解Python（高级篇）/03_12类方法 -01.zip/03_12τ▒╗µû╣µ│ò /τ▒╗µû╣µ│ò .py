
class MyClass(object):
    @classmethod
    def cm1(cls, p1, p2):
        print(p1, p2)

    @classmethod
    def cm2(cls):
        MyClass.cm1(1, 2)
        cls.cm1(1, 2)

    def im(self):
        self.cm1(1, 2)

MyClass.cm1(1, 2)   

mc = MyClass()

mc.cm1(1, 2) 
mc.cm2()

mc.im()
