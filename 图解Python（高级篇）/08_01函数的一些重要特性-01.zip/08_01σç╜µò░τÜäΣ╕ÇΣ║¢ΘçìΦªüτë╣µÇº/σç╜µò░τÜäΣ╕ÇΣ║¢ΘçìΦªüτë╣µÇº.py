
def add(num1, num2):
    return num1 + num2

print(add)  

f = add
print(f(1, 2))  


def eval_square(x):
    return x * x

result = map(eval_square, [1, 2, 3, 4])
print(list(result))


def do_sth():
    return add

print(do_sth()(1, 2))   


def outer():
    def inner():
        print("This is inner.")
    return inner

outer()()  
