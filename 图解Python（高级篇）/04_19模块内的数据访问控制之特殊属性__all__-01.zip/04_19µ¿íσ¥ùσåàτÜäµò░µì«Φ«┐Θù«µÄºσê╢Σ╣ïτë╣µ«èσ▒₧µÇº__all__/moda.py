
from mod import *

print(v1)
print(f1())
print(C1)

# print(v2)
# print(f2())
# print(C2)